/**
 * Copyright (c) 2014, Oracle and/or its affiliates.
 * All rights reserved.
 */
"use strict";var l={"AUS_CANBERRA":[null,"Canberra"],"NZL_WELLINGTON":[null,"Wellington"]};var r={"AUS_CANBERRA":[4380,3205],"NZL_WELLINGTON":[6384,3576]};(this?this:window)['DvtBaseMapManager']['_UNPROCESSED_MAPS'][0].push(["australia","cities",l,r,null,null,4,[110,-1,6720,4452]]);
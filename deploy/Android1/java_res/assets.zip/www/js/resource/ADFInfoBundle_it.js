/* Copyright (c) 2011, 2012, Oracle and/or its affiliates. All rights reserved. */
/* ------------------------------------------------------ */
/* ------------------- ADFInfoBundle_it.js ---------------------- */
/* ------------------------------------------------------ */
// AUTO-GENERATED FILE
// since this gets loaded programmatically, adf.mf.resource will already be defined

adf.mf.resource.ADFInfoBundle_it={
"WARN_SKIP_REMOTE_WRITE":"Java non \u00e8 disponibile, pertanto la scrittura remota verr\u00e0 saltata.",
"LBL_WARNING_DISPLAY_STR":"Avvertenza",
"WARN_MESSAGE_FOR_SELENIUM_TEST":"Messaggio di avvertenza per il test Selenium con argomento: {0}",
"LBL_CONFIRMATION_DISPLAY_STR":"Conferma",
"LBL_INFO_DISPLAY_STR":"Informazioni",
"WARN_PROCESSING_REMOVE_DATA_CHANGE":"Rilevato problema durante l\'elaborazione della modifica ai dati (rimozione)",
"WARN_PROCESSING_UPDATE_DATA_CHANGE":"Rilevato problema durante l\'elaborazione della modifica ai dati (aggiornamento)",
"LBL_OK_DISPLAY_STR":"OK",
"WARN_PROCESSING_CREATE_DATA_CHANGE":"Rilevato problema durante l\'elaborazione della modifica ai dati (creazione)",
"LBL_FATAL_DISPLAY_STR":"Irreversibile",
"WARN_PROCESSING_VAR_CHANGES":"Errore in processDataChangeEvent durante l\'elaborazione delle modifiche alle variabili ",
"LBL_ERROR_DISPLAY_STR":"Errore",
"WARN_COLLECTION_MODEL_NOT_FOUND":"Impossibile trovare il modello di raccolta",
"WARN_UNABLE_TO_FETCH_SET":"Impossibile recuperare il set",
"WARN_UPDATING_CACHE":"Rilevato problema durante l\'aggiornamento della cache come risultato di un evento di modifica dati.",
"WARN_PROCESSING_PROVIDER_CHANGES":"Errore in processDataChangeEvent durante l\'elaborazione delle modifiche del provider.",
"oracle.core.ojdl.logging.MessageIdKeyResourceBundle":""
}
